const express = require('express');
const bcrypt = require('bcryptjs');
const {
  get,
  all,
  run,
  transaction,
  getSetting,
  setSetting,
  exportDatabaseSnapshot,
  importDatabaseSnapshot,
  markCoreDataModified,
} = require('../db');
const { seedIfNeeded } = require('../seed');
const {
  COOKIE_NAME,
  LEGACY_COOKIE_NAMES,
  isSecureRequest,
  validatePasswordStrength,
  encryptSecretValue,
  signUserToken,
  authenticate,
  evaluatePermission,
  writeAudit,
  denyPermission,
} = require('../rbac');
const { getOAuthCredentials, getBaseOrigin } = require('./oauth');
const {
  getGmailConfig,
  isDeliverableEmail,
  sendTestGmail,
  getRecentEmailLogs,
} = require('../mailer');
const { getStorageStatus } = require('../cloudSync');

const router = express.Router();
router.use(authenticate);

router.get('/storage-status', (req, res) => {
  const canViewStorage =
    evaluatePermission(req.user, 'roles.manage').allowed ||
    evaluatePermission(req.user, 'users.manage').allowed;
  if (!canViewStorage) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'عرض حالة التخزين بالسيرفر',
      canRequestElevation: false,
    });
  }
  res.json(getStorageStatus(true));
});

function makeSlug(text, prefix = 'item') {
  const clean = String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return clean || `${prefix}-${Date.now().toString(36)}`;
}

function canCallerModifyRank(caller, targetRank) {
  if (caller.role_slug === 'chairman') return true;
  const callerRank = Number(caller.roleRank || 0);
  return Number(targetRank || 0) < callerRank;
}

function deleteUserCompletely(targetId) {
  transaction(() => {
    const sovereignMembership = get(
      `SELECT 1 AS ok
       FROM users u
       LEFT JOIN departments d ON d.id = u.department_id
       LEFT JOIN departments pd ON pd.id = u.preferred_department_id
       WHERE u.id = ?
         AND (COALESCE(d.is_chairman_exclusive, 0) = 1 OR COALESCE(pd.is_chairman_exclusive, 0) = 1)`,
      [targetId]
    );
    if (sovereignMembership) {
      run(`UPDATE audit_logs SET is_chairman_exclusive = 1 WHERE actor_id = ?`, [targetId]);
    }

    run(`UPDATE users SET approved_by = NULL WHERE approved_by = ?`, [targetId]);
    run(`UPDATE boards SET created_by = NULL WHERE created_by = ?`, [targetId]);
    run(`UPDATE cards SET created_by = NULL WHERE created_by = ?`, [targetId]);
    run(`UPDATE permission_requests SET reviewed_by = NULL WHERE reviewed_by = ?`, [targetId]);
    run(`UPDATE permission_grants SET granted_by = NULL WHERE granted_by = ?`, [targetId]);
    run(
      `UPDATE permission_grants
       SET request_id = NULL
       WHERE request_id IN (SELECT id FROM permission_requests WHERE requester_id = ?)`,
      [targetId]
    );
    run(`UPDATE audit_logs SET actor_id = NULL WHERE actor_id = ?`, [targetId]);

    run(`DELETE FROM board_stars WHERE user_id = ?`, [targetId]);
    run(`DELETE FROM card_assignees WHERE user_id = ?`, [targetId]);
    run(`DELETE FROM card_comments WHERE user_id = ?`, [targetId]);
    run(`DELETE FROM permission_grants WHERE user_id = ?`, [targetId]);
    run(`DELETE FROM permission_requests WHERE requester_id = ?`, [targetId]);
    run(`DELETE FROM notifications WHERE user_id = ?`, [targetId]);

    run(`DELETE FROM users WHERE id = ?`, [targetId]);
  });
}

// ==========================================
// ROLES & PERMISSIONS MATRIX (DB-Driven + Ranked Hierarchy)
// ==========================================

router.get('/roles', (req, res) => {
  const canRoles = evaluatePermission(req.user, 'roles.manage').allowed;
  const canUsers = evaluatePermission(req.user, 'users.manage').allowed;

  if (!canRoles && !canUsers) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'عرض مصفوفة الأدوار والصلاحيات',
      canRequestElevation: false,
    });
  }

  const isChairman = req.user.role_slug === 'chairman';
  const permissions = all(`SELECT * FROM permissions ORDER BY sort_order ASC`);
  const roles = all(
    `SELECT r.*,
            (
              SELECT COUNT(*)
              FROM users u
              LEFT JOIN departments d ON d.id = u.department_id
              LEFT JOIN departments pd ON pd.id = u.preferred_department_id
              WHERE u.role_id = r.id
                AND (? = 1 OR (COALESCE(d.is_chairman_exclusive, 0) = 0 AND COALESCE(pd.is_chairman_exclusive, 0) = 0))
            ) AS users_count
     FROM roles r
     ORDER BY r.rank_level DESC, r.id ASC`,
    [isChairman ? 1 : 0]
  );
  const rpRows = all(`SELECT role_id, permission_key FROM role_permissions`);
  const mapByRole = new Map();
  for (const row of rpRows) {
    if (!mapByRole.has(row.role_id)) mapByRole.set(row.role_id, []);
    mapByRole.get(row.role_id).push(row.permission_key);
  }

  res.json({
    permissions,
    roles: roles.map((r) => ({
      ...r,
      is_protected: Boolean(r.is_protected),
      can_caller_edit:
        r.slug !== 'pending_onboarding' && canCallerModifyRank(req.user, r.rank_level),
      permissions: mapByRole.get(r.id) || [],
    })),
  });
});

router.post('/roles', (req, res) => {
  if (!evaluatePermission(req.user, 'roles.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'إنشاء دور وظيفي جديد',
      canRequestElevation: false,
    });
  }

  const body = req.body || {};
  const name = String(body.name || '').trim();
  const description = String(body.description || '').trim().slice(0, 300);
  const color = /^#[0-9a-fA-F]{6}$/.test(body.color || '') ? body.color : '#0a6fa8';
  const permKeys = Array.isArray(body.permissions) ? body.permissions.map(String) : [];

  const maxAllowedRank =
    req.user.role_slug === 'chairman' ? 95 : Math.max(10, Number(req.user.roleRank || 60) - 10);
  const requestedRank = body.rankLevel !== undefined ? Number(body.rankLevel) : 30;
  const rankLevel = Math.max(5, Math.min(maxAllowedRank, Number.isFinite(requestedRank) ? requestedRank : 30));

  if (name.length < 2 || name.length > 60) {
    return res.status(400).json({ error: 'اسم الدور يجب أن يكون بين حرفين و60 حرفاً' });
  }

  const dupName = get(`SELECT id FROM roles WHERE name = ?`, [name]);
  if (dupName) {
    return res.status(409).json({ error: 'يوجد دور بنفس الاسم بالفعل' });
  }

  const validKeys = new Set(all(`SELECT key FROM permissions`).map((p) => p.key));
  const filteredKeys = [...new Set(permKeys.filter((k) => validKeys.has(k)))];
  const slug = `${makeSlug(body.slug || name, 'role')}-${Date.now().toString(36).slice(-4)}`;

  let roleId;
  transaction(() => {
    roleId = run(
      `INSERT INTO roles (slug, name, description, color, rank_level, is_protected)
       VALUES (?, ?, ?, ?, ?, 0)`,
      [slug, name, description, color, rankLevel]
    ).lastInsertRowid;

    for (const k of filteredKeys) {
      run(`INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)`, [roleId, k]);
    }
  });

  writeAudit({
    user: req.user,
    action: 'إنشاء دور وظيفي جديد في قاعدة البيانات',
    permissionKey: 'roles.manage',
    status: 'ALLOWED',
    req,
    details: `${name} (${filteredKeys.length} صلاحية)`,
  });

  res.status(201).json({
    id: roleId,
    slug,
    name,
    description,
    color,
    rank_level: rankLevel,
    is_protected: false,
    can_caller_edit: true,
    users_count: 0,
    permissions: filteredKeys,
  });
});

router.put('/roles/:id(\\d+)', (req, res) => {
  if (!evaluatePermission(req.user, 'roles.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'تعديل مصفوفة صلاحيات دور وظيفي',
      canRequestElevation: false,
    });
  }

  const roleId = Number(req.params.id);
  const role = get(`SELECT * FROM roles WHERE id = ?`, [roleId]);
  if (!role) return res.status(404).json({ error: 'الدور غير موجود' });

  if (role.slug === 'pending_onboarding') {
    return res.status(400).json({
      error: 'دور (بانتظار التسكين في قسم) مخصص أمنياً للمسجلين الجدد بدون أي صلاحيات حتى يضمهم رئيس القسم.',
    });
  }

  // Enforce Sovereign Role Hierarchy!
  if (!canCallerModifyRank(req.user, role.rank_level)) {
    writeAudit({
      user: req.user,
      action: `محاولة تعديل دور أعلى أو مساوٍ في الرتبة السيادية (${role.name})`,
      permissionKey: 'roles.manage',
      status: 'DENIED',
      req,
    });
    return res.status(403).json({
      error:
        role.slug === 'chairman'
          ? 'حماية سيادية: دور (رئيس مجلس الإدارة) هو الأعلى في النظام ولا يمكن تعديله إلا من حساب رئيس مجلس الإدارة شخصياً.'
          : `لا يمكنك تعديل صلاحيات دور (${role.name}) لأنه يماثل أو يعلو رتبتك الإدارية.`,
    });
  }

  const body = req.body || {};
  const name = body.name !== undefined ? String(body.name).trim() : role.name;
  const description =
    body.description !== undefined ? String(body.description).trim().slice(0, 300) : role.description;
  const color = /^#[0-9a-fA-F]{6}$/.test(body.color || '') ? body.color : role.color;

  if (name.length < 2 || name.length > 60) {
    return res.status(400).json({ error: 'اسم الدور يجب أن يكون بين حرفين و60 حرفاً' });
  }

  const dupName = get(`SELECT id FROM roles WHERE name = ? AND id != ?`, [name, role.id]);
  if (dupName) {
    return res.status(409).json({ error: 'يوجد دور آخر بنفس الاسم' });
  }

  const validKeys = new Set(all(`SELECT key FROM permissions`).map((p) => p.key));
  const nextKeys = Array.isArray(body.permissions)
    ? [...new Set(body.permissions.map(String).filter((k) => validKeys.has(k)))]
    : all(`SELECT permission_key FROM role_permissions WHERE role_id = ?`, [role.id]).map(
        (r) => r.permission_key
      );

  // Sovereign protection: Chairman role can NEVER lose core sovereign permissions
  if (role.slug === 'chairman') {
    for (const mustHave of ['roles.manage', 'users.manage', 'departments.manage', 'boards.view_all']) {
      if (!nextKeys.includes(mustHave)) nextKeys.push(mustHave);
    }
  }

  // Anti-lockout safety: ensure at least 1 active user retains roles.manage
  if (!nextKeys.includes('roles.manage')) {
    const otherAdmins = get(
      `SELECT COUNT(*) AS cnt
       FROM users u
       JOIN role_permissions rp ON rp.role_id = u.role_id
       WHERE u.is_active = 1
         AND u.onboarding_status = 'approved'
         AND u.role_id != ?
         AND rp.permission_key = 'roles.manage'`,
      [role.id]
    );
    if (!otherAdmins || otherAdmins.cnt === 0) {
      return res.status(400).json({
        error:
          'حماية النظام: لا يمكن نزع صلاحية (إدارة الأدوار ومصفوفة الصلاحيات) من آخر دور إداري نشط حتى لا يتم قفل لوحة التحكم بالكامل.',
      });
    }
  }

  transaction(() => {
    run(`UPDATE roles SET name = ?, description = ?, color = ? WHERE id = ?`, [
      name,
      description,
      color,
      role.id,
    ]);
    run(`DELETE FROM role_permissions WHERE role_id = ?`, [role.id]);
    for (const k of nextKeys) {
      run(`INSERT INTO role_permissions (role_id, permission_key) VALUES (?, ?)`, [role.id, k]);
    }

    const members = all(`SELECT id FROM users WHERE role_id = ? AND is_active = 1 AND id != ?`, [
      role.id,
      req.user.id,
    ]);
    for (const m of members) {
      run(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES (?, 'role_updated', 'تحديث صلاحيات دورك الوظيفي', ?)`,
        [
          m.id,
          `قامت الإدارة بتحديث صلاحيات دور (${name}) في قاعدة البيانات، وتم تطبيقها فوراً على حسابك.`,
        ]
      );
    }
  });

  writeAudit({
    user: req.user,
    action: 'تحديث مصفوفة الصلاحيات في قاعدة البيانات',
    permissionKey: 'roles.manage',
    status: 'ALLOWED',
    req,
    details: `دور (${name}) — إجمالي الصلاحيات المفعلة: ${nextKeys.length}`,
  });

  res.json({
    id: role.id,
    slug: role.slug,
    name,
    description,
    color,
    rank_level: role.rank_level,
    is_protected: Boolean(role.is_protected),
    can_caller_edit: true,
    permissions: nextKeys,
  });
});

router.delete('/roles/:id(\\d+)', (req, res) => {
  if (!evaluatePermission(req.user, 'roles.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'حذف دور وظيفي',
      canRequestElevation: false,
    });
  }

  const roleId = Number(req.params.id);
  const role = get(`SELECT * FROM roles WHERE id = ?`, [roleId]);
  if (!role) return res.status(404).json({ error: 'الدور غير موجود' });

  if (role.is_protected) {
    return res.status(400).json({ error: 'هذا الدور أساسي في النظام ولا يمكن حذفه (يمكنك تعديل صلاحياته)' });
  }

  if (!canCallerModifyRank(req.user, role.rank_level)) {
    return res.status(403).json({ error: 'لا يمكنك حذف دور يماثل أو يعلو رتبتك الإدارية' });
  }

  const assignedCount = get(`SELECT COUNT(*) AS cnt FROM users WHERE role_id = ?`, [role.id]).cnt;
  if (assignedCount > 0) {
    return res.status(400).json({
      error: `لا يمكن حذف هذا الدور لوجود (${assignedCount}) موظفين مسجلين عليه حالياً. قم بنقلهم لدور آخر أولاً.`,
    });
  }

  run(`DELETE FROM roles WHERE id = ?`, [role.id]);

  writeAudit({
    user: req.user,
    action: 'حذف دور وظيفي',
    permissionKey: 'roles.manage',
    status: 'ALLOWED',
    req,
    details: role.name,
  });

  res.json({ ok: true });
});

// ==========================================
// USERS MANAGEMENT (الموظفون والحسابات)
// ==========================================

router.get('/users', (req, res) => {
  if (!evaluatePermission(req.user, 'users.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'users.manage',
      actionLabel: 'إدارة حسابات الموظفين',
      canRequestElevation: false,
    });
  }

  const isChairman = req.user.role_slug === 'chairman';
  const users = all(
    `SELECT u.id, u.username, u.email, u.full_name, u.job_title, u.avatar_color, u.avatar_url,
            u.auth_provider, u.onboarding_status, u.preferred_department_id,
            u.role_id, u.department_id, u.is_active, u.created_at,
            r.slug AS role_slug, r.name AS role_name, r.color AS role_color, r.rank_level,
            d.name AS department_name, d.color AS department_color, d.is_chairman_exclusive AS dept_exclusive,
            pd.name AS preferred_department_name, pd.is_chairman_exclusive AS pref_dept_exclusive
     FROM users u
     JOIN roles r ON r.id = u.role_id
     LEFT JOIN departments d ON d.id = u.department_id
     LEFT JOIN departments pd ON pd.id = u.preferred_department_id
     WHERE (COALESCE(d.is_chairman_exclusive, 0) = 0 AND COALESCE(pd.is_chairman_exclusive, 0) = 0)
        OR ? = 1
        OR u.id = ?
     ORDER BY r.rank_level DESC, u.id ASC`,
    [isChairman ? 1 : 0, req.user.id]
  ).map((u) => {
    const isSovereignProtected = Boolean(Number(u.dept_exclusive)) && !isChairman;
    return {
      ...u,
      is_active: Boolean(u.is_active),
      can_caller_edit:
        !isSovereignProtected &&
        (u.id === req.user.id || canCallerModifyRank(req.user, u.rank_level)),
      can_caller_delete:
        !isSovereignProtected &&
        u.id !== req.user.id &&
        u.role_slug !== 'chairman' &&
        canCallerModifyRank(req.user, u.rank_level),
    };
  });

  res.json(users);
});

router.post('/users', async (req, res) => {
  if (!evaluatePermission(req.user, 'users.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'users.manage',
      actionLabel: 'إضافة موظف جديد',
      canRequestElevation: false,
    });
  }

  const body = req.body || {};
  const username = String(body.username || '').trim().toLowerCase();
  const email = body.email ? String(body.email).trim().toLowerCase() : null;
  const password = String(body.password || '');
  const fullName = String(body.fullName || '').trim();
  const jobTitle = String(body.jobTitle || '').trim().slice(0, 100);
  const roleId = Number(body.roleId);
  const departmentId = body.departmentId ? Number(body.departmentId) : null;
  const avatarColor = /^#[0-9a-fA-F]{6}$/.test(body.avatarColor || '')
    ? body.avatarColor
    : '#0a6fa8';

  if (!/^[a-z0-9_.@-]{3,64}$/.test(username)) {
    return res.status(400).json({
      error: 'اسم المستخدم يجب أن يكون من 3 إلى 64 حرفاً إنجليزياً أو رقماً أو بريداً إلكترونياً بدون مسافات',
    });
  }
  const pwErr = validatePasswordStrength(password, username);
  if (pwErr) {
    return res.status(400).json({ error: pwErr });
  }
  if (fullName.length < 2 || fullName.length > 100) {
    return res.status(400).json({ error: 'الاسم الكامل للموظف مطلوب' });
  }

  const dup = get(`SELECT id FROM users WHERE LOWER(username) = LOWER(?)`, [username]);
  if (dup) {
    return res.status(409).json({ error: 'اسم المستخدم مسجل مسبقاً لموظف آخر' });
  }
  if (email) {
    if (!isDeliverableEmail(email)) {
      return res.status(400).json({ error: 'صيغة البريد الإلكتروني غير صحيحة' });
    }
    const dupEmail = get(`SELECT id FROM users WHERE LOWER(email) = LOWER(?)`, [email]);
    if (dupEmail) {
      return res.status(409).json({ error: 'البريد الإلكتروني مسجل مسبقاً لحساب آخر' });
    }
  }

  const role = get(`SELECT * FROM roles WHERE id = ?`, [roleId]);
  if (!role) return res.status(400).json({ error: 'الدور الوظيفي المحدد غير صالح' });

  if (!canCallerModifyRank(req.user, role.rank_level)) {
    return res.status(403).json({
      error: `لا يمكنك إنشاء حساب بدور (${role.name}) لأنه يماثل أو يعلو رتبتك الإدارية`,
    });
  }

  let dept = null;
  if (departmentId === null) {
    if (!req.user.permissionSet.has('boards.view_all')) {
      return res.status(403).json({
        error: 'لا تملك صلاحية إنشاء حساب عام بدون قسم؛ يرجى اختيار القسم المختص للموظف',
      });
    }
  } else {
    dept = get(`SELECT * FROM departments WHERE id = ?`, [departmentId]);
    if (!dept) return res.status(400).json({ error: 'القسم المحدد غير موجود' });
    if (Number(dept.is_chairman_exclusive) && req.user.role_slug !== 'chairman') {
      return res.status(403).json({
        error: 'حماية سيادية: هذا القسم خاص ومرتبط مباشرةً برئيس مجلس الإدارة فقط ولا يمكن إضافة موظفين إليه إلا من حساب رئيس مجلس الإدارة شخصياً.',
      });
    }
  }

  const hash = await bcrypt.hash(password, 12);
  const onboardingStatus = role.slug === 'pending_onboarding' ? 'pending' : 'approved';
  const newUserId = run(
    `INSERT INTO users (
      username, email, email_verified, password_hash, full_name, job_title, avatar_color,
      auth_provider, onboarding_status, role_id, department_id, preferred_department_id, approved_by, approved_at
     ) VALUES (?, ?, 0, ?, ?, ?, ?, 'local', ?, ?, ?, ?, ?, datetime('now'))`,
    [
      username,
      email,
      hash,
      fullName,
      jobTitle,
      avatarColor,
      onboardingStatus,
      role.id,
      dept ? dept.id : null,
      dept ? dept.id : null,
      req.user.id,
    ]
  ).lastInsertRowid;

  writeAudit({
    user: req.user,
    action: 'إضافة حساب موظف جديد',
    permissionKey: 'users.manage',
    status: 'ALLOWED',
    req,
    details: `${fullName} (@${username}) — دور: ${role.name} — قسم: ${dept ? dept.name : 'عام'}`,
    departmentId: dept ? dept.id : null,
    isChairmanExclusive: Boolean(dept && Number(dept.is_chairman_exclusive)),
  });

  res.status(201).json({ id: newUserId, ok: true });
});

router.patch('/users/:id(\\d+)', async (req, res) => {
  if (!evaluatePermission(req.user, 'users.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'users.manage',
      actionLabel: 'تعديل بيانات أو صلاحيات موظف',
      canRequestElevation: false,
    });
  }

  const targetId = Number(req.params.id);
  const existing = get(
    `SELECT u.*, r.rank_level AS current_rank, r.slug AS current_role_slug, r.name AS current_role_name,
            d.is_chairman_exclusive AS current_dept_exclusive,
            pd.is_chairman_exclusive AS pref_dept_exclusive
     FROM users u
     JOIN roles r ON r.id = u.role_id
     LEFT JOIN departments d ON d.id = u.department_id
     LEFT JOIN departments pd ON pd.id = u.preferred_department_id
     WHERE u.id = ?`,
    [targetId]
  );
  if (!existing) return res.status(404).json({ error: 'الموظف غير موجود' });

  if (
    (Number(existing.current_dept_exclusive) || Number(existing.pref_dept_exclusive)) &&
    req.user.role_slug !== 'chairman' &&
    targetId !== req.user.id
  ) {
    return res.status(403).json({
      error: 'حماية سيادية: هذا الحساب يتبع قسماً خاصاً برئيس مجلس الإدارة ولا يمكن تعديله إلا من رئيس مجلس الإدارة شخصياً.',
    });
  }

  // Sovereign Rank Protection on Target User
  if (targetId !== req.user.id && !canCallerModifyRank(req.user, existing.current_rank)) {
    writeAudit({
      user: req.user,
      action: `محاولة تعديل حساب أعلى في الرتبة السيادية (${existing.full_name})`,
      permissionKey: 'users.manage',
      status: 'DENIED',
      req,
    });
    return res.status(403).json({
      error:
        existing.current_role_slug === 'chairman'
          ? 'حماية سيادية: حساب رئيس مجلس الإدارة محمي ولا يمكن تعديله أو إيقافه من أي حساب آخر.'
          : `لا يمكنك تعديل حساب (${existing.full_name}) لأن دوره (${existing.current_role_name}) يماثل أو يعلو رتبتك الإدارية.`,
    });
  }

  const body = req.body || {};
  const fullName =
    body.fullName !== undefined ? String(body.fullName).trim() : existing.full_name;
  const email =
    body.email !== undefined
      ? String(body.email || '').trim().toLowerCase() || null
      : existing.email;
  const jobTitle =
    body.jobTitle !== undefined ? String(body.jobTitle).trim().slice(0, 100) : existing.job_title;
  const roleId = body.roleId !== undefined ? Number(body.roleId) : existing.role_id;
  const departmentId =
    body.departmentId === null || body.departmentId === ''
      ? null
      : body.departmentId !== undefined
      ? Number(body.departmentId)
      : existing.department_id;
  const isActive =
    body.isActive !== undefined ? (body.isActive ? 1 : 0) : existing.is_active;

  if (fullName.length < 2 || fullName.length > 100) {
    return res.status(400).json({ error: 'الاسم الكامل للموظف مطلوب (بين حرفين و100 حرف)' });
  }
  if (email) {
    if (!isDeliverableEmail(email)) {
      return res.status(400).json({ error: 'صيغة البريد الإلكتروني غير صحيحة' });
    }
    const dupEmail = get(
      `SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND id != ?`,
      [email, existing.id]
    );
    if (dupEmail) {
      return res.status(409).json({ error: 'البريد الإلكتروني مسجل مسبقاً لحساب آخر' });
    }
  }

  if (targetId === req.user.id && !isActive) {
    return res.status(400).json({ error: 'لا يمكنك إيقاف حسابك الشخصي أثناء تسجيل دخولك' });
  }

  if (existing.current_role_slug === 'chairman' && !isActive) {
    return res.status(400).json({ error: 'حماية سيادية: لا يمكن إيقاف حساب رئيس مجلس الإدارة' });
  }

  const role = get(`SELECT * FROM roles WHERE id = ?`, [roleId]);
  if (!role) return res.status(400).json({ error: 'الدور المحدد غير موجود' });

  // Sovereign Rank Protection on New Role Assignment
  if (
    role.id !== existing.role_id &&
    !canCallerModifyRank(req.user, role.rank_level)
  ) {
    return res.status(403).json({
      error: `لا يمكنك منح دور (${role.name}) لأنه يماثل أو يعلو رتبتك الإدارية`,
    });
  }

  if (departmentId === null) {
    if (
      existing.department_id !== null &&
      !req.user.permissionSet.has('boards.view_all')
    ) {
      return res.status(403).json({
        error: 'لا تملك صلاحية نقل حساب إلى الإدارة العليا بدون قسم؛ يرجى اختيار قسم محدد للموظف',
      });
    }
  } else {
    const dept = get(`SELECT * FROM departments WHERE id = ?`, [departmentId]);
    if (!dept) return res.status(400).json({ error: 'القسم المحدد غير موجود' });
    if (
      Number(dept.is_chairman_exclusive) &&
      req.user.role_slug !== 'chairman' &&
      Number(existing.department_id) !== Number(dept.id)
    ) {
      return res.status(403).json({
        error: 'حماية سيادية: لا يمكن نقل موظف إلى قسم خاص برئيس مجلس الإدارة إلا من حساب رئيس مجلس الإدارة شخصياً.',
      });
    }
  }

  // Prevent removing last active roles.manage holder
  const nextRoleHasManage = Boolean(
    get(
      `SELECT 1 AS ok FROM role_permissions WHERE role_id = ? AND permission_key = 'roles.manage'`,
      [role.id]
    )
  );
  if (!isActive || !nextRoleHasManage) {
    const remainingManagers = get(
      `SELECT COUNT(*) AS cnt
       FROM users u
       JOIN role_permissions rp ON rp.role_id = u.role_id
       WHERE u.is_active = 1
         AND u.onboarding_status = 'approved'
         AND u.id != ?
         AND rp.permission_key = 'roles.manage'`,
      [existing.id]
    );
    if (!remainingManagers || remainingManagers.cnt === 0) {
      return res.status(400).json({
        error: 'حماية النظام: يجب بقاء حساب نشط واحد على الأقل يحمل صلاحية إدارة الأدوار والصلاحيات.',
      });
    }
  }

  let passwordHash = existing.password_hash;
  let bumpToken = !isActive && existing.is_active ? 1 : 0;

  if (body.newPassword && String(body.newPassword).length > 0) {
    const nextPass = String(body.newPassword);
    const pwErr = validatePasswordStrength(nextPass, existing.username);
    if (pwErr) {
      return res.status(400).json({ error: pwErr });
    }
    passwordHash = await bcrypt.hash(nextPass, 12);
    bumpToken = 1;
  }

  const nextOnboardingStatus =
    role.slug === 'pending_onboarding' ? 'pending' : 'approved';
  const departmentChanged =
    Number(departmentId || 0) !== Number(existing.department_id || 0);
  const nextEmailVerified =
    String(email || '').toLowerCase() === String(existing.email || '').toLowerCase()
      ? Number(existing.email_verified || 0)
      : 0;

  transaction(() => {
    run(
      `UPDATE users
       SET full_name = ?, email = ?, email_verified = ?, job_title = ?, role_id = ?,
           department_id = ?, preferred_department_id = ?,
           onboarding_status = ?,
           approved_by = COALESCE(approved_by, ?),
           approved_at = COALESCE(approved_at, datetime('now')),
           is_active = ?, password_hash = ?, token_version = token_version + ?
       WHERE id = ?`,
      [
        fullName,
        email,
        nextEmailVerified,
        jobTitle,
        role.id,
        departmentId,
        departmentId,
        nextOnboardingStatus,
        req.user.id,
        isActive,
        passwordHash,
        bumpToken,
        existing.id,
      ]
    );
    if (departmentChanged) {
      run(`UPDATE permission_grants SET is_revoked = 1 WHERE user_id = ? AND is_revoked = 0`, [
        existing.id,
      ]);
    }
  });

  writeAudit({
    user: req.user,
    action: 'تحديث حساب وصلاحيات موظف',
    permissionKey: 'users.manage',
    status: 'ALLOWED',
    req,
    details: `${fullName} — الدور: ${role.name} — الحالة: ${isActive ? 'نشط' : 'موقوف'}`,
    departmentId: departmentId || existing.department_id,
    isChairmanExclusive: Boolean(
      Number(existing.current_dept_exclusive) || Number(existing.pref_dept_exclusive)
    ),
  });

  // If caller rotated their own password, issue a fresh token immediately so their session stays active
  let refreshedToken = null;
  if (existing.id === req.user.id && bumpToken > 0) {
    const updatedSelf = get(`SELECT * FROM users WHERE id = ?`, [existing.id]);
    refreshedToken = signUserToken(updatedSelf);
    const isHttps = isSecureRequest(req);
    res.cookie(COOKIE_NAME, refreshedToken, {
      httpOnly: true,
      sameSite: 'lax',
      secure: isHttps,
      maxAge: 12 * 3600 * 1000,
    });
  }

  res.json({ ok: true, token: refreshedToken });
});

router.delete('/users/:id(\\d+)', (req, res) => {
  if (!evaluatePermission(req.user, 'users.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'users.manage',
      actionLabel: 'حذف حساب موظف نهائياً',
      canRequestElevation: false,
    });
  }

  const targetId = Number(req.params.id);
  if (targetId === req.user.id) {
    return res.status(400).json({ error: 'لا يمكنك حذف حسابك الشخصي أثناء تسجيل دخولك' });
  }

  const existing = get(
    `SELECT u.*, r.rank_level AS current_rank, r.slug AS current_role_slug, r.name AS current_role_name,
            d.name AS current_department_name, d.is_chairman_exclusive AS current_dept_exclusive,
            pd.is_chairman_exclusive AS pref_dept_exclusive
     FROM users u
     JOIN roles r ON r.id = u.role_id
     LEFT JOIN departments d ON d.id = u.department_id
     LEFT JOIN departments pd ON pd.id = u.preferred_department_id
     WHERE u.id = ?`,
    [targetId]
  );
  if (!existing) {
    return res.status(404).json({ error: 'الموظف غير موجود أو تم حذفه مسبقاً' });
  }

  if (existing.current_role_slug === 'chairman') {
    writeAudit({
      user: req.user,
      action: `محاولة حذف الحساب السيادي لرئيس مجلس الإدارة (${existing.full_name})`,
      permissionKey: 'users.manage',
      status: 'DENIED',
      req,
    });
    return res.status(403).json({
      error: 'حماية سيادية: حساب رئيس مجلس الإدارة محمي ولا يمكن حذفه نهائياً تحت أي ظرف.',
    });
  }

  if (
    (Number(existing.current_dept_exclusive) || Number(existing.pref_dept_exclusive)) &&
    req.user.role_slug !== 'chairman'
  ) {
    writeAudit({
      user: req.user,
      action: `محاولة حذف حساب يتبع قسماً خاصاً برئيس مجلس الإدارة`,
      permissionKey: 'users.manage',
      status: 'DENIED',
      req,
      isChairmanExclusive: true,
    });
    return res.status(403).json({
      error: 'حماية سيادية: هذا الحساب يتبع قسماً خاصاً برئيس مجلس الإدارة ولا يمكن حذفه إلا من رئيس مجلس الإدارة شخصياً.',
    });
  }

  if (!canCallerModifyRank(req.user, existing.current_rank)) {
    writeAudit({
      user: req.user,
      action: `محاولة حذف حساب أعلى أو مساوٍ في الرتبة السيادية (${existing.full_name})`,
      permissionKey: 'users.manage',
      status: 'DENIED',
      req,
    });
    return res.status(403).json({
      error: `لا يمكنك حذف حساب (${existing.full_name}) لأن دوره (${existing.current_role_name}) يماثل أو يعلو رتبتك الإدارية.`,
    });
  }

  // Anti-lockout safety: ensure at least 1 active roles.manage holder remains
  const remainingManagers = get(
    `SELECT COUNT(*) AS cnt
     FROM users u
     JOIN role_permissions rp ON rp.role_id = u.role_id
     WHERE u.is_active = 1
       AND u.onboarding_status = 'approved'
       AND u.id != ?
       AND rp.permission_key = 'roles.manage'`,
    [existing.id]
  );
  if (!remainingManagers || remainingManagers.cnt === 0) {
    return res.status(400).json({
      error: 'حماية النظام: لا يمكن حذف آخر حساب نشط يحمل صلاحية إدارة الأدوار والصلاحيات.',
    });
  }

  deleteUserCompletely(existing.id);

  writeAudit({
    user: req.user,
    action: 'حذف حساب موظف نهائياً من النظام',
    permissionKey: 'users.manage',
    status: 'ALLOWED',
    req,
    details: `${existing.full_name} (@${existing.username}) — الدور: ${existing.current_role_name} — القسم: ${
      existing.current_department_name || 'غير مسكن'
    }`,
    departmentId: existing.department_id,
    isChairmanExclusive: Boolean(
      Number(existing.current_dept_exclusive) || Number(existing.pref_dept_exclusive)
    ),
  });

  return res.json({
    ok: true,
    message: `تم حذف حساب (${existing.full_name}) نهائياً من النظام بنجاح`,
  });
});

// ==========================================
// DEPARTMENTS MANAGEMENT (أقسام الشركة)
// ==========================================

router.get('/departments', (req, res) => {
  const canDepts = evaluatePermission(req.user, 'departments.manage').allowed;
  const canUsers = evaluatePermission(req.user, 'users.manage').allowed;
  if (!canDepts && !canUsers) {
    return denyPermission(req, res, {
      permissionKey: 'departments.manage',
      actionLabel: 'إدارة أقسام الشركة',
      canRequestElevation: false,
    });
  }

  const isChairman = req.user.role_slug === 'chairman';
  const depts = all(
    `SELECT d.*,
            (SELECT COUNT(*) FROM users u WHERE u.department_id = d.id AND u.onboarding_status = 'approved') AS users_count,
            (SELECT COUNT(*) FROM boards b WHERE b.department_id = d.id) AS boards_count
     FROM departments d
     WHERE d.is_chairman_exclusive = 0 OR ? = 1
     ORDER BY d.id ASC`,
    [isChairman ? 1 : 0]
  ).map((d) => ({
    ...d,
    is_chairman_exclusive: Boolean(Number(d.is_chairman_exclusive)),
  }));

  res.json(depts);
});

router.post('/departments', (req, res) => {
  if (!evaluatePermission(req.user, 'departments.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'departments.manage',
      actionLabel: 'إنشاء قسم جديد بالشركة',
      canRequestElevation: false,
    });
  }

  const body = req.body || {};
  const name = String(body.name || '').trim();
  const description = String(body.description || '').trim().slice(0, 300);
  const color = /^#[0-9a-fA-F]{6}$/.test(body.color || '') ? body.color : '#0a6fa8';
  const icon = String(body.icon || 'briefcase').trim().slice(0, 30);
  const isChairmanExclusive = Boolean(body.isChairmanExclusive) ? 1 : 0;

  if (isChairmanExclusive && req.user.role_slug !== 'chairman') {
    return res.status(403).json({
      error: 'حماية سيادية: إنشاء قسم سيادي خاص برئيس مجلس الإدارة متاح لحساب رئيس مجلس الإدارة فقط',
    });
  }

  if (name.length < 2 || name.length > 80) {
    return res.status(400).json({ error: 'اسم القسم يجب أن يكون بين حرفين و80 حرفاً' });
  }

  const dup = get(`SELECT id FROM departments WHERE name = ?`, [name]);
  if (dup) return res.status(409).json({ error: 'يوجد قسم بنفس الاسم بالفعل' });

  const slug = `${makeSlug(body.slug || name, 'dept')}-${Date.now().toString(36).slice(-4)}`;
  const id = run(
    `INSERT INTO departments (slug, name, description, color, icon, is_chairman_exclusive) VALUES (?, ?, ?, ?, ?, ?)`,
    [slug, name, description, color, icon, isChairmanExclusive]
  ).lastInsertRowid;

  writeAudit({
    user: req.user,
    action: 'إضافة قسم جديد بالشركة',
    permissionKey: 'departments.manage',
    status: 'ALLOWED',
    req,
    details: name,
    departmentId: id,
    isChairmanExclusive: Boolean(isChairmanExclusive),
  });

  res.status(201).json(get(`SELECT * FROM departments WHERE id = ?`, [id]));
});

router.patch('/departments/:id(\\d+)', (req, res) => {
  if (!evaluatePermission(req.user, 'departments.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'departments.manage',
      actionLabel: 'تعديل بيانات قسم',
      canRequestElevation: false,
    });
  }

  const dept = get(`SELECT * FROM departments WHERE id = ?`, [Number(req.params.id)]);
  if (!dept) return res.status(404).json({ error: 'القسم غير موجود' });

  if (Number(dept.is_chairman_exclusive) && req.user.role_slug !== 'chairman') {
    return res.status(403).json({
      error: 'حماية سيادية: تعديل الأقسام الخاصة برئيس مجلس الإدارة متاح لحساب رئيس مجلس الإدارة فقط',
    });
  }

  const body = req.body || {};
  const name = body.name !== undefined ? String(body.name).trim() : dept.name;
  const description =
    body.description !== undefined ? String(body.description).trim().slice(0, 300) : dept.description;
  const color = /^#[0-9a-fA-F]{6}$/.test(body.color || '') ? body.color : dept.color;
  const isChairmanExclusive =
    body.isChairmanExclusive !== undefined
      ? Boolean(body.isChairmanExclusive)
        ? 1
        : 0
      : Number(dept.is_chairman_exclusive);

  if (isChairmanExclusive !== Number(dept.is_chairman_exclusive) && req.user.role_slug !== 'chairman') {
    return res.status(403).json({
      error: 'حماية سيادية: تغيير خصوصية القسم السيادية متاح لحساب رئيس مجلس الإدارة فقط',
    });
  }

  if (name.length < 2 || name.length > 80) {
    return res.status(400).json({ error: 'اسم القسم غير صالح' });
  }

  const dup = get(`SELECT id FROM departments WHERE name = ? AND id != ?`, [name, dept.id]);
  if (dup) return res.status(409).json({ error: 'يوجد قسم آخر بنفس الاسم' });

  run(
    `UPDATE departments SET name = ?, description = ?, color = ?, is_chairman_exclusive = ? WHERE id = ?`,
    [name, description, color, isChairmanExclusive, dept.id]
  );

  writeAudit({
    user: req.user,
    action: 'تحديث بيانات قسم',
    permissionKey: 'departments.manage',
    status: 'ALLOWED',
    req,
    details: name,
    departmentId: dept.id,
    isChairmanExclusive: Boolean(Number(dept.is_chairman_exclusive) || isChairmanExclusive),
  });

  res.json(get(`SELECT * FROM departments WHERE id = ?`, [dept.id]));
});

router.delete('/departments/:id(\\d+)', (req, res) => {
  if (!evaluatePermission(req.user, 'departments.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'departments.manage',
      actionLabel: 'حذف قسم من الشركة',
      canRequestElevation: false,
    });
  }

  const dept = get(`SELECT * FROM departments WHERE id = ?`, [Number(req.params.id)]);
  if (!dept) return res.status(404).json({ error: 'القسم غير موجود' });

  if (Number(dept.is_chairman_exclusive) && req.user.role_slug !== 'chairman') {
    return res.status(403).json({
      error: 'حماية سيادية: حذف الأقسام الخاصة برئيس مجلس الإدارة متاح لحساب رئيس مجلس الإدارة فقط',
    });
  }

  const boardsCount = get(`SELECT COUNT(*) AS cnt FROM boards WHERE department_id = ?`, [dept.id]).cnt;
  const usersCount = get(`SELECT COUNT(*) AS cnt FROM users WHERE department_id = ?`, [dept.id]).cnt;

  if (boardsCount > 0 || usersCount > 0) {
    return res.status(400).json({
      error: `لا يمكن حذف القسم لارتباطه بـ (${boardsCount}) لوحات عمل و(${usersCount}) موظفين. انقلهم أولاً.`,
    });
  }

  const wasExclusive = Boolean(Number(dept.is_chairman_exclusive));
  run(`DELETE FROM departments WHERE id = ?`, [dept.id]);

  writeAudit({
    user: req.user,
    action: 'حذف قسم',
    permissionKey: 'departments.manage',
    status: 'ALLOWED',
    req,
    details: dept.name,
    departmentId: dept.id,
    isChairmanExclusive: wasExclusive,
  });

  res.json({ ok: true });
});

// ==========================================
// GOOGLE OAUTH 2.0 CONFIGURATION (لـ IT والإدارة العليا)
// ==========================================

router.get('/oauth-settings', (req, res) => {
  if (
    !evaluatePermission(req.user, 'roles.manage').allowed &&
    !evaluatePermission(req.user, 'users.manage').allowed
  ) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'عرض إعدادات ربط تسجيل الدخول عبر Google',
      canRequestElevation: false,
    });
  }

  const creds = getOAuthCredentials();
  const origin = getBaseOrigin(req);

  res.json({
    googleClientId: getSetting('google_client_id', process.env.GOOGLE_CLIENT_ID || ''),
    googleSecretSaved: Boolean(creds.googleClientSecret),
    googleConfigured: Boolean(creds.googleClientId && creds.googleClientSecret),
    googleCallbackUrl: `${origin}/api/auth/oauth/google/callback`,
  });
});

router.put('/oauth-settings', (req, res) => {
  if (!evaluatePermission(req.user, 'roles.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'تحديث مفاتيح الربط مع Google',
      canRequestElevation: false,
    });
  }

  const body = req.body || {};
  if (body.googleClientId !== undefined) {
    setSetting('google_client_id', String(body.googleClientId || '').trim());
  }
  if (body.googleClientSecret !== undefined && String(body.googleClientSecret).trim() !== '') {
    setSetting(
      'google_client_secret',
      encryptSecretValue(String(body.googleClientSecret).trim().slice(0, 256))
    );
  }
  if (body.clearGoogleSecret) {
    setSetting('google_client_secret', '');
  }

  writeAudit({
    user: req.user,
    action: 'تحديث إعدادات تسجيل الدخول عبر Google',
    permissionKey: 'roles.manage',
    status: 'ALLOWED',
    req,
  });

  const creds = getOAuthCredentials();
  res.json({
    ok: true,
    googleConfigured: Boolean(creds.googleClientId && creds.googleClientSecret),
  });
});

// ==========================================
// GMAIL NOTIFICATIONS INTEGRATION (ربط إشعارات Gmail)
// ==========================================

router.get('/gmail-settings', (req, res) => {
  if (
    !evaluatePermission(req.user, 'roles.manage').allowed &&
    !evaluatePermission(req.user, 'users.manage').allowed
  ) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'عرض إعدادات ربط إشعارات Gmail',
      canRequestElevation: false,
    });
  }

  const cfg = getGmailConfig();
  res.json({
    gmailUser: cfg.gmailUser,
    appPasswordSaved: Boolean(cfg.gmailAppPassword),
    configured: cfg.configured,
    enabled: cfg.enabled,
    senderName: cfg.senderName,
    adminNotifyEmail: cfg.adminNotifyEmail,
    emailLogs: getRecentEmailLogs(40, {
      includeChairmanExclusive: req.user.role_slug === 'chairman',
    }),
  });
});

router.put('/gmail-settings', (req, res) => {
  if (!evaluatePermission(req.user, 'roles.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'تحديث إعدادات ربط إشعارات Gmail',
      canRequestElevation: false,
    });
  }

  const body = req.body || {};
  if (body.gmailUser !== undefined) {
    const cleanGmail = String(body.gmailUser || '').trim().toLowerCase();
    if (cleanGmail && !isDeliverableEmail(cleanGmail)) {
      return res.status(400).json({ error: 'صيغة بريد Gmail المرسل غير صحيحة' });
    }
    setSetting('gmail_user', cleanGmail);
  }
  if (
    body.gmailAppPassword !== undefined &&
    String(body.gmailAppPassword).replace(/\s+/g, '') !== ''
  ) {
    setSetting(
      'gmail_app_password',
      encryptSecretValue(String(body.gmailAppPassword).replace(/\s+/g, '').slice(0, 128))
    );
  }
  if (body.clearAppPassword) {
    setSetting('gmail_app_password', '');
  }
  if (body.senderName !== undefined) {
    setSetting(
      'gmail_sender_name',
      String(body.senderName || '')
        .replace(/[\r\n]+/g, ' ')
        .trim()
        .slice(0, 100)
    );
  }
  if (body.adminNotifyEmail !== undefined) {
    const cleanAdminCc = String(body.adminNotifyEmail || '').trim().toLowerCase();
    if (cleanAdminCc && !isDeliverableEmail(cleanAdminCc)) {
      return res.status(400).json({ error: 'صيغة بريد استلام إشعارات الإدارة غير صحيحة' });
    }
    setSetting('gmail_admin_cc', cleanAdminCc);
  }
  if (body.enabled !== undefined) {
    setSetting('gmail_enabled', body.enabled ? '1' : '0');
  }

  writeAudit({
    user: req.user,
    action: 'تحديث إعدادات ربط إشعارات Gmail',
    permissionKey: 'roles.manage',
    status: 'ALLOWED',
    req,
  });

  const cfg = getGmailConfig();
  res.json({
    ok: true,
    configured: cfg.configured,
    enabled: cfg.enabled,
  });
});

router.post('/gmail-settings/test', async (req, res) => {
  if (!evaluatePermission(req.user, 'roles.manage').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'roles.manage',
      actionLabel: 'إرسال بريد اختباري عبر Gmail',
      canRequestElevation: false,
    });
  }

  try {
    const targetEmail = req.body && req.body.targetEmail;
    const result = await sendTestGmail(targetEmail);
    writeAudit({
      user: req.user,
      action: 'إرسال إيميل تجريبي عبر Gmail بنجاح',
      permissionKey: 'roles.manage',
      status: 'ALLOWED',
      req,
      details: `إلى: ${result.to}`,
    });
    res.json(result);
  } catch (err) {
    const code = err.statusCode || 500;
    res.status(code).json({ error: err.message || 'تعذر إرسال الرسالة التجريبية' });
  }
});

// ==========================================
// SECURITY AUDIT LOGS
// ==========================================

router.get('/audit-logs', (req, res) => {
  if (!evaluatePermission(req.user, 'audit.view').allowed) {
    return denyPermission(req, res, {
      permissionKey: 'audit.view',
      actionLabel: 'عرض سجل المراقبة الأمنية للعمليات',
      canRequestElevation: false,
    });
  }

  const isChairman = req.user.role_slug === 'chairman';
  const statusFilter = String(req.query.status || 'ALL').toUpperCase();
  const q = String(req.query.q || '').trim();

  const where = [];
  const params = [];

  if (!isChairman) {
    where.push('al.is_chairman_exclusive = 0');
    where.push(
      `NOT EXISTS (
        SELECT 1 FROM users u
        LEFT JOIN departments d ON d.id = u.department_id
        LEFT JOIN departments pd ON pd.id = u.preferred_department_id
        WHERE u.id = al.actor_id
          AND (COALESCE(d.is_chairman_exclusive, 0) = 1 OR COALESCE(pd.is_chairman_exclusive, 0) = 1)
      )`
    );
  }

  if (statusFilter === 'ALLOWED' || statusFilter === 'DENIED') {
    where.push('al.status = ?');
    params.push(statusFilter);
  }
  if (q) {
    where.push(
      "(al.actor_name LIKE ? ESCAPE '\\' OR al.action LIKE ? ESCAPE '\\' OR al.details LIKE ? ESCAPE '\\' OR al.permission_key LIKE ? ESCAPE '\\')"
    );
    const escapedQ = q.slice(0, 100).replace(/[\\%_]/g, '\\$&');
    const p = `%${escapedQ}%`;
    params.push(p, p, p, p);
  }

  const sql = `
    SELECT al.* FROM audit_logs al
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY al.id DESC
    LIMIT 150
  `;

  res.json(all(sql, params));
});

// ==========================================
// SOVEREIGN DATA BACKUP EXPORT & RESTORE (رئيس مجلس الإدارة فقط)
// ==========================================
router.get('/backup/export', (req, res) => {
  if (req.user.role_slug !== 'chairman') {
    return res.status(403).json({
      error: 'تصدير واستعادة النسخة الاحتياطية الكاملة مخصص لحساب رئيس مجلس الإدارة فقط',
    });
  }

  const snapshot = exportDatabaseSnapshot();
  writeAudit({
    user: req.user,
    action: 'تصدير نسخة احتياطية كاملة لقاعدة بيانات المنصة',
    status: 'ALLOWED',
    req,
  });

  res.json({
    ok: true,
    snapshot,
  });
});

const backupJsonParser = express.json({ limit: '5mb' });

router.post(
  '/backup/import',
  (req, res, next) => {
    if (req.user.role_slug !== 'chairman') {
      return res.status(403).json({
        error: 'استعادة النسخة الاحتياطية الكاملة مخصص لحساب رئيس مجلس الإدارة فقط',
      });
    }
    return backupJsonParser(req, res, next);
  },
  (req, res) => {
    const snapshot = req.body && (req.body.snapshot || req.body);
    if (
      !snapshot ||
      typeof snapshot !== 'object' ||
      !snapshot.tables ||
      !Array.isArray(snapshot.tables.users) ||
      !Array.isArray(snapshot.tables.roles)
    ) {
      return res.status(400).json({
        error: 'ملف النسخة الاحتياطية غير صالح — يرجى رفع ملف JSON المستخرج من المنصة',
      });
    }

    const chairmanRole = snapshot.tables.roles.find((r) => r.slug === 'chairman');
    const hasChairmanUser =
      chairmanRole &&
      snapshot.tables.users.some(
        (u) => Number(u.role_id) === Number(chairmanRole.id) && Number(u.is_active) !== 0
      );

    if (!hasChairmanUser) {
      return res.status(400).json({
        error: 'رفض أمني: النسخة المرفوعة لا تحتوي على حساب رئيس مجلس الإدارة المفعل',
      });
    }

    try {
      importDatabaseSnapshot(snapshot, {
        requireActiveChairman: true,
        preserveMissingSecrets: true,
      });
      seedIfNeeded();
      markCoreDataModified();
    } catch (err) {
      return res.status(400).json({
        error: 'تعذر استعادة النسخة الاحتياطية — تأكد من سلامة بنية ملف الـ JSON وتكامل العلاقات وعدم تلفه',
      });
    }

  const restoredChairman = get(
    `SELECT u.*
     FROM users u
     JOIN roles r ON r.id = u.role_id
     WHERE r.slug = 'chairman' AND u.is_active = 1
     ORDER BY u.id ASC LIMIT 1`
  );

  let refreshedToken = null;
  if (restoredChairman) {
    refreshedToken = signUserToken(restoredChairman);
    const isHttps = isSecureRequest(req);
    for (const oldName of LEGACY_COOKIE_NAMES || []) res.clearCookie(oldName);
    res.cookie(COOKIE_NAME, refreshedToken, {
      httpOnly: true,
      sameSite: 'lax',
      secure: isHttps,
      maxAge: 12 * 3600 * 1000,
    });
  }

  writeAudit({
    user: req.user,
    action: 'استعادة نسخة احتياطية كاملة لقاعدة بيانات المنصة',
    status: 'ALLOWED',
    req,
    details: `عدد المستخدمين: ${snapshot.tables.users.length} — عدد اللوحات: ${(snapshot.tables.boards || []).length}`,
    isChairmanExclusive: true,
  });

  res.json({
    ok: true,
    token: refreshedToken,
    message: 'تم استعادة كافة بيانات الشركة والموظفين واللوحات بنجاح 100%',
  });
  }
);

router.deleteUserCompletely = deleteUserCompletely;
module.exports = router;
