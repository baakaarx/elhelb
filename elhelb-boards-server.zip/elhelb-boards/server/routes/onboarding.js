const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { all, get, run, transaction } = require('../db');
const {
  COOKIE_NAME,
  LEGACY_COOKIE_NAMES,
  isSecureRequest,
  validateEmployeeFullName,
  validatePasswordStrength,
  signUserToken,
  authenticate,
  userHasPermission,
  writeAudit,
} = require('../rbac');
const { sendElhelbEmail } = require('../mailer');
const { getStorageStatus } = require('../cloudSync');
const adminRoutes = require('./admin');

const router = express.Router();
router.use(authenticate);

const preferenceLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: process.env.NODE_ENV === 'test' ? 40 : 6,
  keyGenerator: (req) => `${req.ip || 'unknown'}::${req.user ? req.user.id : 'anon'}`,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'تم تغيير القسم عدة مرات، يرجى الانتظار قليلاً قبل التعديل مجدداً' },
});

// Step 1: Pending employee sets initial credentials (OAuth) or updates pending credentials (with currentPassword)
router.post('/setup-credentials', async (req, res) => {
  try {
    if (req.user.onboarding_status !== 'pending') {
      return res.status(403).json({
        error: 'تم اعتماد حسابك بالفعل؛ لتعديل بيانات الدخول يرجى مراجعة إدارة الموارد البشرية أو مسؤول النظام',
      });
    }

    const body = req.body || {};
    const username = String(body.username || '')
      .trim()
      .toLowerCase();
    const password = String(body.password || '');
    const currentPassword = String(body.currentPassword || '');
    const fullName =
      body.fullName !== undefined
        ? String(body.fullName).trim()
        : req.user.full_name;

    const rawSelf = get(`SELECT * FROM users WHERE id = ?`, [req.user.id]);
    if (!rawSelf) {
      return res.status(404).json({ error: 'الحساب غير موجود' });
    }

    // Require currentPassword whenever the account already has custom local credentials
    if (Boolean(rawSelf.has_custom_credentials) && Boolean(rawSelf.password_hash)) {
      if (!currentPassword) {
        return res.status(400).json({
          error: 'يرجى إدخال كلمة المرور الحالية أولاً لتأكيد تعديل اسم المستخدم أو كلمة المرور',
        });
      }
      const matchesCurrent = await bcrypt.compare(currentPassword, rawSelf.password_hash);
      if (!matchesCurrent) {
        return res.status(403).json({
          error: 'كلمة المرور الحالية غير صحيحة',
        });
      }
    }

    if (!/^[a-z0-9_.-]{3,36}$/.test(username)) {
      return res.status(400).json({
        error:
          'اسم المستخدم يجب أن يتكون من 3 إلى 36 حرفاً إنجليزياً أو رقماً (بدون مسافات، مثل: ahmed.ali)',
      });
    }
    const pwErr = validatePasswordStrength(password, username);
    if (pwErr) {
      return res.status(400).json({ error: pwErr });
    }
    const nameCheck = validateEmployeeFullName(fullName, {
      allowExecutiveTitles: false,
      minLen: 2,
    });
    if (!nameCheck.ok) {
      return res.status(400).json({ error: nameCheck.error });
    }
    const safeFullName = nameCheck.clean;

    const duplicate = get(
      `SELECT id FROM users WHERE LOWER(username) = LOWER(?) AND id != ?`,
      [username, req.user.id]
    );
    if (duplicate) {
      return res.status(409).json({
        error: 'اسم المستخدم هذا مستخدم بالفعل لموظف آخر، يرجى اختيار اسم مختلف',
      });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    run(
      `UPDATE users
       SET username = ?,
           password_hash = ?,
           full_name = ?,
           has_custom_credentials = 1,
           token_version = token_version + 1
       WHERE id = ?`,
      [username, passwordHash, safeFullName, req.user.id]
    );

    const updatedSelf = get(`SELECT * FROM users WHERE id = ?`, [req.user.id]);
    const refreshedToken = signUserToken(updatedSelf);
    const isHttps = isSecureRequest(req);
    for (const oldName of LEGACY_COOKIE_NAMES || []) res.clearCookie(oldName);
    res.cookie(COOKIE_NAME, refreshedToken, {
      httpOnly: true,
      sameSite: 'lax',
      secure: isHttps,
      maxAge: 12 * 3600 * 1000,
    });

    writeAudit({
      user: { ...req.user, full_name: `${safeFullName} (@${username})` },
      action: 'إنشاء اسم مستخدم وكلمة مرور خاصة بالموظف',
      status: 'ALLOWED',
      req,
      details: `اسم المستخدم الجديد: @${username}`,
    });

    return res.json({
      ok: true,
      token: refreshedToken,
      username,
      fullName: safeFullName,
    });
  } catch (err) {
    console.error('Setup credentials error:', err);
    return res.status(500).json({ error: 'تعذر حفظ اسم المستخدم وكلمة المرور' });
  }
});

// Step 2: Employee selects their Department -> notifies HR (الموارد البشرية) & Top Management!
router.patch('/my-preference', preferenceLimiter, async (req, res) => {
  try {
    if (req.user.onboarding_status !== 'pending') {
      return res.status(403).json({
        error: 'تم اعتماد حسابك وتسكينك بالفعل؛ لتعديل القسم أو المسمى الوظيفي يرجى مراجعة إدارة الموارد البشرية (HR)',
      });
    }

    const { preferredDepartmentId, jobTitle } = req.body || {};

    if (!preferredDepartmentId) {
      return res.status(400).json({ error: 'يرجى اختيار القسم الذي تعمل به في الشركة' });
    }

    const dept = get(`SELECT * FROM departments WHERE id = ?`, [
      Number(preferredDepartmentId),
    ]);
    if (!dept) {
      return res.status(400).json({ error: 'القسم المختار غير موجود' });
    }

    // Sovereign protection: self-service pending users CANNOT select sovereign departments
    // (nor use them to hide their audit trail or evade HR/IT review)
    if (Boolean(Number(dept.is_chairman_exclusive))) {
      return res.status(403).json({
        error: 'حماية سيادية: التسكين في هذا القسم يتم مباشرةً من حساب رئيس مجلس الإدارة فقط',
      });
    }

    const cleanJobTitle =
      typeof jobTitle === 'string' ? jobTitle.trim().slice(0, 100) : req.user.job_title;

    const prevSelf = get(
      `SELECT preferred_department_id, department_confirmed FROM users WHERE id = ?`,
      [req.user.id]
    );
    const deptActuallyChanged =
      !prevSelf ||
      !Number(prevSelf.department_confirmed) ||
      Number(prevSelf.preferred_department_id || 0) !== Number(dept.id);

    run(
      `UPDATE users
       SET preferred_department_id = ?,
           job_title = ?,
           department_confirmed = 1
       WHERE id = ?`,
      [dept.id, cleanJobTitle || '', req.user.id]
    );

    // Anti-mail-bombing & anti-notification-flood:
    // Only notify managers when the department actually changed, and cap SMTP onboarding email to ONCE per pending account!
    if (deptActuallyChanged) {
      const priorNotifCountRow = get(
        `SELECT COUNT(*) AS cnt FROM notifications
         WHERE type = 'onboarding_pref' AND message LIKE ? ESCAPE '\\'`,
        [`%— @${String(req.user.username || '').replace(/[\\%_]/g, '\\$&')})%`]
      );
      const priorNotifCount = priorNotifCountRow ? Number(priorNotifCountRow.cnt) : 0;

      if (priorNotifCount < 3) {
        const managerEmails = [];
        const notifyManagers = all(
          `SELECT u.id, u.email, u.email_verified, u.department_id, r.slug AS role_slug,
                  MAX(CASE WHEN rp.permission_key = 'users.manage' THEN 1 ELSE 0 END) AS has_global_users_manage
           FROM users u
           JOIN roles r ON r.id = u.role_id
           JOIN role_permissions rp ON rp.role_id = u.role_id
           WHERE u.is_active = 1
             AND u.onboarding_status = 'approved'
             AND rp.permission_key IN ('department.onboard_members', 'users.manage')
           GROUP BY u.id`
        );

        for (const m of notifyManagers) {
          const shouldNotify =
            Boolean(m.has_global_users_manage) ||
            !m.department_id ||
            Number(m.department_id) === Number(dept.id);

          if (shouldNotify) {
            run(
              `INSERT INTO notifications (user_id, type, title, message, link_tab)
               VALUES (?, 'onboarding_pref', 'طلب تسكين موظف جديد بانتظار اعتماد الـ HR', ?, 'onboarding')`,
              [
                m.id,
                `الموظف (${req.user.full_name} — @${req.user.username}) سجل حسابه وطلب الانضمام إلى (${dept.name}) وبانتظار القبول والتسكين.`,
              ]
            );
            if (m.email && Number(m.email_verified) === 1) {
              managerEmails.push(m.email);
            }
          }
        }

        // Send external SMTP alert at most ONCE for the initial department selection
        if (priorNotifCount === 0) {
          await sendElhelbEmail({
            to: managerEmails,
            ccAdmin: true,
            isChairmanExclusive: false,
            eventType: 'onboarding_request',
            subject: `👤 طلب تسكين موظف جديد في (${dept.name}) — ${req.user.full_name} (@${req.user.username})`,
            badgeText: 'طلب تسكين موظف جديد (HR)',
            badgeColor: '#d97706',
            heading: `قام (${req.user.full_name} — @${req.user.username}) بالتسجيل وتحديد قسمه في مجموعة الهلب`,
            bodyLines: [
              `أنشأ الموظف حسابه وحدد أنه تابع لـ (${dept.name}).`,
              `يرجى الدخول إلى تبويب "تسكين وقبول الموظفين (HR)" لاعتماده وتحديد دوره الوظيفي.`,
            ],
            details: [
              ['الاسم الكامل للموظف', req.user.full_name],
              ['اسم المستخدم المختار', `@${req.user.username}`],
              ['البريد الإلكتروني', req.user.email || '—'],
              ['القسم المطلوب الانضمام إليه', dept.name],
              ['المسمى الوظيفي', cleanJobTitle || 'غير محدد بعد'],
            ],
          });
        }
      }
    }

    return res.json({
      ok: true,
      preferredDepartmentId: dept.id,
      preferredDepartmentName: dept.name,
      departmentConfirmed: true,
    });
  } catch (err) {
    console.error('Update onboarding preference error:', err);
    return res.status(500).json({ error: 'تعذر حفظ اختيار القسم' });
  }
});

// List pending employees + company/department team roster for HR, IT & Top Management
router.get('/pending', (req, res) => {
  const canManageAll = userHasPermission(req.user, 'users.manage');
  const canOnboardDept = userHasPermission(req.user, 'department.onboard_members');

  if (!canManageAll && !canOnboardDept) {
    writeAudit({
      user: req.user,
      action: 'محاولة فتح شاشة تسكين الموظفين بدون صلاحية HR أو إدارة',
      permissionKey: 'users.manage',
      status: 'DENIED',
      req,
    });
    return res.status(403).json({
      code: 'PERMISSION_DENIED',
      permissionKey: 'users.manage',
      error: 'هذه الشاشة مخصصة لإدارة الموارد البشرية (HR) ومسؤولي الـ IT والإدارة العليا فقط',
    });
  }

  const myDeptId = req.user.department_id || null;
  const callerRank = Number(req.user.roleRank || 0);
  const isChairman = req.user.role_slug === 'chairman';

  const pendingUsers = canManageAll
    ? all(
        `SELECT
           u.id, u.username, u.email, u.full_name, u.job_title,
           u.avatar_color, u.avatar_url, u.auth_provider,
           u.has_custom_credentials, u.department_confirmed,
           u.onboarding_status, u.preferred_department_id, u.created_at,
           pd.name AS preferred_department_name,
           pd.slug AS preferred_department_slug,
           pd.color AS preferred_department_color
         FROM users u
         LEFT JOIN departments pd ON pd.id = u.preferred_department_id
         WHERE u.onboarding_status = 'pending'
           AND u.is_active = 1
           AND (COALESCE(pd.is_chairman_exclusive, 0) = 0 OR ? = 1)
         ORDER BY u.department_confirmed DESC, u.id DESC`,
        [isChairman ? 1 : 0]
      )
    : all(
        `SELECT
           u.id, u.username, u.email, u.full_name, u.job_title,
           u.avatar_color, u.avatar_url, u.auth_provider,
           u.has_custom_credentials, u.department_confirmed,
           u.onboarding_status, u.preferred_department_id, u.created_at,
           pd.name AS preferred_department_name,
           pd.slug AS preferred_department_slug,
           pd.color AS preferred_department_color
         FROM users u
         LEFT JOIN departments pd ON pd.id = u.preferred_department_id
         WHERE u.onboarding_status = 'pending'
           AND u.is_active = 1
           AND COALESCE(pd.is_chairman_exclusive, 0) = 0
           AND u.preferred_department_id = ?
         ORDER BY
           u.department_confirmed DESC,
           u.id DESC`,
        [myDeptId || -1]
      );

  const assignableDepartments = canManageAll
    ? all(
        `SELECT id, slug, name, color, is_chairman_exclusive
         FROM departments
         WHERE is_chairman_exclusive = 0 OR ? = 1
         ORDER BY id ASC`,
        [isChairman ? 1 : 0]
      )
    : myDeptId
    ? all(
        `SELECT id, slug, name, color, is_chairman_exclusive
         FROM departments
         WHERE id = ? AND is_chairman_exclusive = 0`,
        [myDeptId]
      )
    : [];

  const assignableRoles = all(
    `SELECT id, slug, name, description, color, rank_level
     FROM roles
     WHERE slug != 'pending_onboarding'
       AND rank_level > 0
       AND rank_level < ?
     ORDER BY rank_level DESC, id ASC`,
    [isChairman ? 101 : callerRank]
  );

  const rawTeamMembers = canManageAll
    ? all(
        `SELECT
           u.id, u.username, u.email, u.full_name, u.job_title, u.avatar_color,
           u.auth_provider, u.department_id, u.approved_at, u.is_active,
           d.name AS department_name, d.color AS department_color, d.is_chairman_exclusive,
           r.slug AS role_slug, r.name AS role_name, r.color AS role_color, r.rank_level,
           approver.full_name AS approved_by_name
         FROM users u
         JOIN roles r ON r.id = u.role_id
         LEFT JOIN departments d ON d.id = u.department_id
         LEFT JOIN users approver ON approver.id = u.approved_by
         WHERE u.onboarding_status = 'approved'
           AND u.is_active = 1
           AND (COALESCE(d.is_chairman_exclusive, 0) = 0 OR ? = 1)
         ORDER BY u.department_id ASC, r.rank_level DESC, u.id ASC`,
        [isChairman ? 1 : 0]
      )
    : myDeptId
    ? all(
        `SELECT
           u.id, u.username, u.email, u.full_name, u.job_title, u.avatar_color,
           u.auth_provider, u.department_id, u.approved_at, u.is_active,
           d.name AS department_name, d.color AS department_color,
           r.slug AS role_slug, r.name AS role_name, r.color AS role_color, r.rank_level,
           approver.full_name AS approved_by_name
         FROM users u
         JOIN roles r ON r.id = u.role_id
         LEFT JOIN departments d ON d.id = u.department_id
         LEFT JOIN users approver ON approver.id = u.approved_by
         WHERE u.onboarding_status = 'approved'
           AND u.is_active = 1
           AND u.department_id = ?
         ORDER BY r.rank_level DESC, u.id ASC`,
        [myDeptId]
      )
    : [];

  const teamMembers = rawTeamMembers.map((m) => ({
    ...m,
    can_caller_delete:
      canManageAll &&
      m.id !== req.user.id &&
      m.role_slug !== 'chairman' &&
      (req.user.role_slug === 'chairman' || Number(m.rank_level || 0) < callerRank),
  }));

  res.json({
    pendingUsers,
    assignableDepartments,
    assignableRoles,
    teamMembers,
    canManageAll,
    storageStatus: getStorageStatus(canManageAll),
  });
});

// HR (or IT / Sovereign Admin) approves & assigns a pending employee into their company department!
router.post('/:userId(\\d+)/claim', async (req, res) => {
  try {
    const canManageAll = userHasPermission(req.user, 'users.manage');
    const canOnboardDept = userHasPermission(req.user, 'department.onboard_members');

    if (!canManageAll && !canOnboardDept) {
      writeAudit({
        user: req.user,
        action: 'محاولة قبول وتسكين موظف بدون صلاحية الموارد البشرية (HR)',
        permissionKey: 'users.manage',
        status: 'DENIED',
        req,
      });
      return res.status(403).json({
        code: 'PERMISSION_DENIED',
        permissionKey: 'users.manage',
        error: 'صلاحية قبول وتسكين الموظفين مخصصة لإدارة الموارد البشرية (HR) والإدارة العليا',
      });
    }

    const targetUserId = Number(req.params.userId);
    const targetUser = get(`SELECT * FROM users WHERE id = ?`, [targetUserId]);
    if (!targetUser || !targetUser.is_active) {
      return res.status(404).json({ error: 'الموظف المطلوب غير موجود' });
    }
    if (targetUser.onboarding_status !== 'pending') {
      return res.status(400).json({ error: 'هذا الموظف تم اعتماده وتسكينه بالفعل سابقاً' });
    }

    if (targetUser.preferred_department_id && req.user.role_slug !== 'chairman') {
      const prefDept = get(`SELECT is_chairman_exclusive FROM departments WHERE id = ?`, [
        targetUser.preferred_department_id,
      ]);
      if (prefDept && Number(prefDept.is_chairman_exclusive)) {
        return res.status(403).json({
          error: 'حماية سيادية: طلبات الانضمام للقسم الخاص برئيس مجلس الإدارة تُعتمد من رئيس مجلس الإدارة فقط',
        });
      }
    }

    const body = req.body || {};
    const requestedDeptId = body.departmentId ? Number(body.departmentId) : req.user.department_id;
    const requestedRoleId = Number(body.roleId);
    const jobTitle = String(body.jobTitle || targetUser.job_title || '')
      .trim()
      .slice(0, 100);

    // Enforce strict department scope if user only holds department.onboard_members (without users.manage)
    if (!canManageAll) {
      if (!req.user.department_id) {
        return res.status(400).json({ error: 'حسابك غير مرتبط بقسم محدد' });
      }
      if (requestedDeptId && Number(requestedDeptId) !== Number(req.user.department_id)) {
        writeAudit({
          user: req.user,
          action: 'محاولة ضم موظف إلى قسم آخر بدون صلاحية HR الشاملة',
          permissionKey: 'users.manage',
          status: 'DENIED',
          req,
        });
        return res.status(403).json({
          code: 'DEPARTMENT_ISOLATION',
          error: 'لا تملك صلاحية تسكين موظفين في أقسام أخرى خارج قسمك',
        });
      }
    }

    const targetDeptId = canManageAll ? requestedDeptId : req.user.department_id;
    const dept = get(`SELECT * FROM departments WHERE id = ?`, [Number(targetDeptId)]);
    if (!dept) {
      return res.status(400).json({ error: 'يرجى تحديد القسم الذي سينضم إليه الموظف' });
    }

    if (Number(dept.is_chairman_exclusive) && req.user.role_slug !== 'chairman') {
      writeAudit({
        user: req.user,
        action: `محاولة تسكين موظف في قسم سيادي خاص برئيس مجلس الإدارة (${dept.name})`,
        permissionKey: 'users.manage',
        status: 'DENIED',
        req,
      });
      return res.status(403).json({
        error: 'حماية سيادية: هذا القسم خاص ومرتبط مباشرةً برئيس مجلس الإدارة فقط ولا يمكن التسكين فيه إلا من حساب رئيس مجلس الإدارة شخصياً.',
      });
    }

    const role = get(`SELECT * FROM roles WHERE id = ?`, [requestedRoleId]);
    if (!role || role.slug === 'pending_onboarding' || Number(role.rank_level) <= 0) {
      return res.status(400).json({ error: 'يرجى اختيار دور وظيفي صالح للموظف داخل القسم' });
    }

    const callerRank = Number(req.user.roleRank || 0);
    const targetRoleRank = Number(role.rank_level || 0);
    const allowedRank =
      req.user.role_slug === 'chairman' ? targetRoleRank <= 100 : targetRoleRank < callerRank;

    if (!allowedRank) {
      writeAudit({
        user: req.user,
        action: `محاولة منح رتبة صلاحية أعلى أو مساوية (${role.name})`,
        permissionKey: 'roles.manage',
        status: 'DENIED',
        req,
      });
      return res.status(403).json({
        error: `لا يمكنك منح دور (${role.name}) لأنه يماثل أو يفوق مستوى صلاحيتك الإدارية`,
      });
    }

    let alreadyClaimedRace = false;
    transaction(() => {
      const updated = run(
        `UPDATE users
         SET department_id = ?,
             preferred_department_id = ?,
             role_id = ?,
             job_title = ?,
             department_confirmed = 1,
             onboarding_status = 'approved',
             approved_by = ?,
             approved_at = datetime('now')
         WHERE id = ? AND onboarding_status = 'pending'`,
        [dept.id, dept.id, role.id, jobTitle || role.name, req.user.id, targetUser.id]
      );
      if (updated.changes === 0) {
        alreadyClaimedRace = true;
        return;
      }

      run(
        `INSERT INTO notifications (user_id, type, title, message, link_tab)
         VALUES (?, 'onboarding_approved', 'مرحباً بك! تم اعتماد وتسكين حسابك رسمياً 🎉', ?, 'boards')`,
        [
          targetUser.id,
          `قامت إدارة الموارد البشرية / الإدارة (${req.user.full_name}) بتسكينك في (${dept.name}) بدور (${role.name}). يمكنك الآن الدخول إلى لوحات عمل قسمك فوراً.`,
        ]
      );
    });

    if (alreadyClaimedRace) {
      return res.status(400).json({ error: 'هذا الموظف تم اعتماده وتسكينه بالفعل سابقاً' });
    }

    const isExclusiveClaim = Boolean(Number(dept.is_chairman_exclusive));

    writeAudit({
      user: req.user,
      action: `اعتماد وتسكين موظف جديد: ${targetUser.full_name}`,
      permissionKey: canManageAll ? 'users.manage' : 'department.onboard_members',
      status: 'ALLOWED',
      req,
      details: `القسم: ${dept.name} — الدور: ${role.name}`,
      departmentId: dept.id,
      isChairmanExclusive: isExclusiveClaim,
    });

    await sendElhelbEmail({
      to: targetUser.email && Number(targetUser.email_verified) === 1 ? [targetUser.email] : [],
      ccAdmin: !isExclusiveClaim,
      isChairmanExclusive: isExclusiveClaim,
      eventType: 'onboarding_approved',
      subject: `🎉 تم اعتماد انضمامك إلى (${dept.name}) — مجموعة الهلب`,
      badgeText: 'تم اعتماد حسابك وتسكينك',
      badgeColor: '#059669',
      heading: `مرحباً بك يا ${targetUser.full_name} في (${dept.name})!`,
      bodyLines: [
        `تمت الموافقة على انضمامك وتسكينك رسمياً بواسطة (${req.user.full_name}).`,
        `أصبحت لوحات العمل والمهام الخاصة بقسمك متاحة لك الآن بالكامل.`,
      ],
      details: [
        ['القسم المعتمد', dept.name],
        ['الدور الوظيفي والصلاحية', role.name],
        ['المسمى الوظيفي', jobTitle || role.name],
        ['اسم المستخدم للدخول المباشر', `@${targetUser.username}`],
        ['تم الاعتماد بواسطة', req.user.full_name],
      ],
    });

    return res.json({
      ok: true,
      message: `تم قبول وتسكين (${targetUser.full_name}) في (${dept.name}) بنجاح`,
    });
  } catch (err) {
    console.error('Claim user error:', err);
    return res.status(500).json({ error: 'تعذر إتمام عملية تسكين الموظف' });
  }
});

// Reject & permanently delete a pending registration request
router.delete('/:userId(\\d+)', (req, res) => {
  const canManageAll = userHasPermission(req.user, 'users.manage');
  const canOnboardDept = userHasPermission(req.user, 'department.onboard_members');

  if (!canManageAll && !canOnboardDept) {
    return res.status(403).json({
      code: 'PERMISSION_DENIED',
      error: 'ليس لديك صلاحية رفض أو حذف طلبات التسجيل',
    });
  }

  const targetUserId = Number(req.params.userId);
  const targetUser = get(`SELECT * FROM users WHERE id = ?`, [targetUserId]);
  if (!targetUser) {
    return res.status(404).json({ error: 'طلب التسجيل غير موجود أو تم حذفه مسبقاً' });
  }
  if (targetUser.onboarding_status !== 'pending') {
    return res.status(400).json({
      error: 'هذا الحساب معتمد بالفعل؛ لحذف موظف حالي استخدم زر الحذف النهائي من قائمة الموظفين',
    });
  }

  if (
    !canManageAll &&
    (!targetUser.preferred_department_id ||
      Number(targetUser.preferred_department_id) !== Number(req.user.department_id))
  ) {
    return res.status(403).json({
      error: 'لا يمكنك حذف طلب انضمام موجه لقسم آخر أو غير محدد لقسمك بعد',
    });
  }

  let isExclusivePref = false;
  if (targetUser.preferred_department_id) {
    const prefDept = get(`SELECT is_chairman_exclusive FROM departments WHERE id = ?`, [
      targetUser.preferred_department_id,
    ]);
    isExclusivePref = Boolean(prefDept && Number(prefDept.is_chairman_exclusive));
    if (isExclusivePref && req.user.role_slug !== 'chairman') {
      return res.status(403).json({
        error: 'حماية سيادية: طلبات الانضمام للقسم الخاص برئيس مجلس الإدارة تُراجع من رئيس مجلس الإدارة فقط',
      });
    }
  }

  adminRoutes.deleteUserCompletely(targetUser.id);

  writeAudit({
    user: req.user,
    action: 'رفض وحذف طلب تسجيل موظف معلق',
    permissionKey: canManageAll ? 'users.manage' : 'department.onboard_members',
    status: 'ALLOWED',
    req,
    details: `${targetUser.full_name} (@${targetUser.username})`,
    departmentId: targetUser.preferred_department_id,
    isChairmanExclusive: isExclusivePref,
  });

  return res.json({
    ok: true,
    message: `تم رفض وحذف طلب تسجيل (${targetUser.full_name}) نهائياً`,
  });
});

module.exports = router;
